require 'lib.sampfuncs'
require 'lib.moonloader'

local sampev = require 'lib.samp.events'

bunuh = 0
lastkill = 0
bunuhl = 1
dead_players = {}

script_name("[KillStream Mobile] by _lil.starss")
script_version("1.0")

function main()
  if not isSampfuncsLoaded() or not isSampLoaded() then return end 
  while not isSampAvailable() do wait(0) end
  sampAddChatMessage(string.format("[KillStream] {FFFFFF}by _lil.starss"), 0x0A8002)
  bunuh = 0
end

function sampev.onSendGiveDamage(playerid, damage, amount, weaponid, bodypart)
	if playerid ~= nil and playerid ~= 65535 then
		if not isPlayerDead(PLAYER_HANDLE) and not damage ~= nil then
			hp = sampGetPlayerHealth(playerid)
			newhp = hp - damage
			if newhp == 0 or newhp < 0 then
				
				if not isPlayerAlreadyDead(playerid) then
				
					table.insert(dead_players, playerid)
		
					if global_thread ~= nil then
						thread_status = global_thread:status()
						if thread_status == 'yielded' or thread_status == 'running' then
							global_thread:terminate()
						end
					end			
					if bunuhl == 0 then
						bunuh = bunuh + 1
					else
						triggerBunuhlKillstream()
					end
					
					lua_thread.create(function()
						wait(5000)
						if isPlayerAlreadyDead(playerid) then
							for k,v in pairs(dead_players) do		
								if dead_players[k] == playerid then
									table.remove(dead_players, k)
								end
							end
						end
					end)
				end
			end
		end
	end
end

function isPlayerAlreadyDead(playerid)
    for k,v in pairs(dead_players) do
		if dead_players[k] == playerid then return true end
	end
	return false
end

function sampev.onSendSpawn()
    bunuh = 0
end

function triggerBunuhlKillstream()
    local kill_1, kill_2, kill_3, kill_4, kill_5, kill_6 = 
    loadAudioStream("sound/Fisrt_Blood.mp3"), 
    loadAudioStream("sound/Double_Kill.mp3"),
    loadAudioStream("sound/Rampage.mp3"),
    loadAudioStream("sound/Unstoppable.mp3"),
    loadAudioStream("sound/UltraKill.mp3"),
    loadAudioStream("sound/MonsterKill.mp3");

    bunuh = bunuh + 1

    if(lastkill < os.time() - 5) then
    	if(bunuh > 5) then
    		bunuh = 1
    	end
    end
    lastkill = os.time()

    local b1, b222_a, b3, b4, b5, b6 = 
    "~r~FIRST BLOOD",
    "~R~DOUBLE KILL",
    "~p~RAMPAGE",
    "~y~UNSTOPPABLE",
    "~r~ULTRAKILL",
    "~p~<~w~ MONSTER KILL ~p~>";

    
    if (bunuh == 1) then 
    	printStyledString(b1,  2500, 4)
		setAudioStreamState(kill_1, 1)
		setAudioStreamVolume(kill_1, 3.0)
    end
    if (bunuh == 2) then 
    	printStyledString(b222_a,  2500, 4)
    	-- printStyledString(b222_a,  2500, 5)
		setAudioStreamState(kill_2, 1)
    	setAudioStreamVolume(kill_2, 3.0)
    end
    if (bunuh == 3) then 
    	printStyledString(b3,  2500, 4)
		setAudioStreamState(kill_3, 1)
    	setAudioStreamVolume(kill_3, 3.0)
    end
    if (bunuh == 4) then 
    	printStyledString(b4,  2500, 4)
		setAudioStreamState(kill_4, 1)
    	setAudioStreamVolume(kill_4, 3.0)
    end
    if (bunuh == 5) then 
    	printStyledString(b5,  5000, 4)
		setAudioStreamState(kill_5, 1)
    	setAudioStreamVolume(kill_5, 3.0)
    end
    if (bunuh >= 6) then 
    	printStyledString(b6,  5000, 4)
		setAudioStreamState(kill_6, 1)
    	setAudioStreamVolume(kill_6, 3.0)
    end
end
