script_name("map")

local imgui = require 'mimgui'
local new = imgui.new
local encoding = require 'encoding'
encoding.default = 'CP1251'
u8 = encoding.UTF8

local map_width, map_height = 1076, 1077
local world_min_x, world_max_x = -3000, 3000
local world_min_y, world_max_y = -3000, 3000

local map_window = new.bool(false)
local map_offset_x, map_offset_y = 0, 0
local marker_x, marker_y = nil, nil

local map_texture = nil
local was_pressed = false

require 'widgets'

local isWidgetPressed = _G.isWidgetPressed
local WIDGET_PHONE = _G.WIDGET_PHONE

if not isWidgetPressed then
    isWidgetPressed = function(id) 
        return false 
    end
end

if not WIDGET_PHONE then
    WIDGET_PHONE = 1
end

imgui.OnInitialize(function()
    map_texture = imgui.CreateTextureFromFile('resource/map.png')
end)

imgui.OnFrame(function() return map_window[0] end, function()
    imgui.SetNextWindowSize(imgui.ImVec2(800, 300), imgui.Cond.FirstUseEver)
    imgui.Begin(u8'�� ������ ����', map_window)

    if map_texture then
        local map_size = imgui.ImVec2(map_width, map_height)
        local map_pos = imgui.GetCursorScreenPos()
        local dl = imgui.GetWindowDrawList()
        
        imgui.Image(map_texture, map_size)
        
        local player_x, player_y = getCharCoordinates(PLAYER_PED)
        local player_img_x = ((player_x - world_min_x) / (world_max_x - world_min_x)) * map_width
        local player_img_y = ((world_max_y - player_y) / (world_max_y - world_min_y)) * map_height
        dl:AddCircleFilled(imgui.ImVec2(map_pos.x + player_img_x + map_offset_x, map_pos.y + player_img_y + map_offset_y), 6, 0xFFFF0000FF)

        local status, waypoint_x, waypoint_y, waypoint_z = getTargetBlipCoordinates()
        if status then
            local waypoint_img_x = ((waypoint_x - world_min_x) / (world_max_x - world_min_x)) * map_width
            local waypoint_img_y = ((world_max_y - waypoint_y) / (world_max_y - world_min_y)) * map_height
            dl:AddCircleFilled(imgui.ImVec2(map_pos.x + waypoint_img_x + map_offset_x, map_pos.y + waypoint_img_y + map_offset_y), 10, 0xFFFF0000, 500)
        end

        if marker_x and marker_y then
            local marker_img_x = ((marker_x - world_min_x) / (world_max_x - world_min_x)) * map_width
            local marker_img_y = ((world_max_y - marker_y) / (world_max_y - world_min_y)) * map_height
            dl:AddCircleFilled(imgui.ImVec2(map_pos.x + marker_img_x + map_offset_x, map_pos.y + marker_img_y + map_offset_y), 10, 0xFF0000FF) 
        end
    end

    imgui.End()
end)

local sampev = require('lib.samp.events')

function sampev.onSetRaceCheckpoint(type, position, nextPosition, size)
    marker_x, marker_y = position.x, position.y
end

function main()
    while not isSampAvailable() do wait(100) end
    
    while true do
        wait(0)
        
        local pressed = isWidgetPressed(WIDGET_PHONE)
        
        if pressed and not was_pressed then
            map_window[0] = not map_window[0]
        end
        
        was_pressed = pressed
    end
end